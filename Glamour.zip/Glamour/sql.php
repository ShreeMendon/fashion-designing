<?php
$sql=mysqli_connect("localhost","root","","fashion_designing");
?>
