-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2019 at 02:27 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fashion_designing`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` int(11) NOT NULL,
  `user` varchar(50) DEFAULT NULL,
  `pass` varchar(50) DEFAULT NULL,
  `activeFlag` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `user`, `pass`, `activeFlag`) VALUES
(1, 'shree', '1821', '1');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `ID` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `repeatpassword` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `Activeflag` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`ID`, `username`, `password`, `repeatpassword`, `email`, `Activeflag`) VALUES
(1, 'shree', '123', '123', 'shreejan0816@gmail.com', 0),
(3, '', '', '', '', 0),
(5, '', '', '', '', 0),
(6, '', '', '', '', 0),
(7, 'swathi', '789', '', '', 0),
(59, '', '', '', '', 0),
(60, '', '', '', '', 0),
(77, '', '', '', '', 0),
(78, '', '', '', '', 0),
(79, '', '', '', '', 0),
(80, '', '', '', '', 0),
(81, '', '', '', '', 0),
(82, '', '', '', '', 0),
(83, '', '', '', '', 0),
(84, '', '', '', '', 0),
(85, '', '', '', '', 0),
(86, '', '', '', '', 0),
(87, '', '', '', '', 0),
(88, '', '', '', '', 0),
(89, '', '', '', '', 0),
(90, '', '', '', '', 0),
(91, '', '', '', '', 0),
(92, '', '', '', '', 0),
(93, '', '', '', '', 0),
(94, '', '', '', '', 0),
(95, '', '', '', '', 0),
(96, '', '', '', '', 0),
(97, '', '', '', '', 0),
(98, '', '', '', '', 0),
(99, '', '', '', '', 0),
(100, '', '', '', '', 0),
(101, '', '', '', '', 0),
(102, '', '', '', '', 0),
(103, '', '', '', '', 0),
(104, '', '', '', '', 0),
(105, '', '', '', '', 0),
(106, '', '', '', '', 0),
(107, 'xyz', 'xyz', '', '', 0),
(108, '', '', '', '', 0),
(109, '', '', '', '', 0),
(110, '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `CATID` int(11) NOT NULL,
  `CATNAME` varchar(50) NOT NULL,
  `PRODUCTID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`CATID`, `CATNAME`, `PRODUCTID`) VALUES
(1, 'womans', 1),
(2, 'mens', 1),
(3, 'jewellery', 1),
(4, 'beauty', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblproduct`
--

CREATE TABLE `tblproduct` (
  `PRODID` int(11) NOT NULL,
  `CATID` int(11) NOT NULL,
  `PRODESC` varchar(200) NOT NULL,
  `PRODQTY` int(11) NOT NULL,
  `PRICE` int(11) NOT NULL,
  `IMAGES` varchar(200) NOT NULL,
  `PRODSTATUS` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`CATID`,`PRODUCTID`);

--
-- Indexes for table `tblproduct`
--
ALTER TABLE `tblproduct`
  ADD PRIMARY KEY (`PRODID`,`CATID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `CATID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblproduct`
--
ALTER TABLE `tblproduct`
  MODIFY `PRODID` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
