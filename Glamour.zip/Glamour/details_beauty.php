<?php
//    $id=$_GET['id'];
//    include_once "sql.php";
//    $res=mysqli_query()
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<style>
    div.container{
        border: 3px solid #ccc;
        height:710px;
        width:100%;

    }
    div.details{
        margin-left:50px;
    }

    div.book-btn{
        margin-top:50px;
    }

    div.gallery {
        margin: 6px;
        /*border: 3px solid #ccc;*!*!*/
        float: left;
    }

    body{
        background-color:black;
    }

    .book-btn a{
        background:#e75b1e;
        color:#fff;
        min-width: 219px;
        padding: 10.5px 20px;
        display: inline-block;
        text-align: center;
        font-weight: 800;
        text-transform:uppercase;
        font-size:18px;
        float: left;
    }
    .book-btn a:hover{
        border:3px solid #e75b1e;
        background:none;
    }

    .cart-btn a{
        background:#ff9f00;
        color:#fff;
        min-width: 219px;
        padding: 10.5px 20px;
        display: inline-block;
        text-align: center;
        font-weight: 800;
        text-transform:uppercase;
        font-size:18px;
        margin-left:3%;
    }
    .cart-btn a:hover{
        border:3px solid #ff9f00;
        background:none;
    }
    div.price{
        color:#fff;
    }
    h2{color:white;}


</style>

<body>
<div class="container">
    <div class="row">
        <div class="col-50">
            <div class="gallery">
                <img src="images/b1.jpg"  width="500" height="680" id="1">
            </div>

            <div class="col-50">
                <div class="details">
                    <div class="description">
                        <h2>
                        </h2>
                    </div>
                    <div class="price">
                        <h1 style="color:grey"> Rs  368</h1>
                    </div>


                    <div>
<!--                        <h4 style="color:white">Composition & Care</h4>-->
                        <p style="color:grey">
                            The glossy LIT Nail Enamels by Glamour promise super long-wear time, guaranteeing endless nights of fun with your
                            digits—whether it’s in real time or some good ol’ sexting. Nothing sets the mood quite like the smooth wet finish of glistening bright nails.
                            We’ve used a formula that improves colour reflection, enhances brightness and brings out shine—time to put those nails to good use.</p>
                        <h4 style="color:white">benifits</h4>
                        <p style="color:grey">
                            1.Sport a fresh manicure with every swipe<br>
                            2.Flawless texture<br>
                            3.Ultra long-lasting formula<br>
                            4.Super solid colour payoff<br>
                            5.Contoured applicator for easy application<br>

                        <h4 style="color:white">Shipping &Packaging</h4>

                        <p style="color:grey">
                            Delivery Time: Within India:7 weeks,International:8 weeks<br>
                            Shipping: The product will be  shipped to you at the earliest.<br>
                            The sending details will be shared with you through email for you to trcck.<br>
                            Packaging: your garment will come wrapped in butter paper, and further <br>packaged and boxed carefully
                            to ensure that your garment reaches you in perfect condition.</p>

                    </div>


<!--                    <h3 style="color:grey">-->
<!--                        Select your size:-->
<!--                        <button style="color:grey">S</button>-->
<!--                        <button style="color:grey">L</button>-->
<!--                        <button style="color:grey">XL</button>-->
<!--                        <button style="color:grey">XXL</button>-->
<!--                        <button style="color:grey">Medium</button>-->
<!--                    </h3>-->
                    <div class="service" style="color:white">
                        *30 Day Return Policy<br>
                        *Cash on Delivery available
                    </div><br>

                    <div class="row">
                        <div class="col-50">
                            <div class="book-btn">
                                <a href="#"> Add to cart </a>
                            </div>
                        </div>

                        <div class="col-50">
                            <div class="cart-btn">
                                <a href="cart.php"> buy now </a>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>


    </div>
</div>
</html>

