<?php
?>
<!DOCTYPE html>
<html>
<head>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <style>
        div.gallery {
            margin: 5px;
            border: 1px solid #ccc;
            float: left;
            width: 355px;
            padding:20px;
            margin-left:5%;
            margin-top:6%;
        }

        div.gallery:hover {
            border: 1px solid #777;
        }

        div.gallery img {
            width: 100%;
            height: auto;

        }

        div.desc {
            padding: 20px;
            text-align: center;
            color:gray;

        }
        body{
            background-color:black;
        }
    </style>
</head>
<body>
<div class="gallery ">
    <a target="_blank" href="details.php?id=1">
        <img id="w1" src="images/ww1.jpg" alt="Cinque Terre" width="500" height="400">
    </a>
    <div class="desc">Exclusive Designer Red Lehenga Set-Bridal Lehenga Store CM334 </div>
</div>

<div class="gallery ">
    <a target="_blank" href="details.php?id=1">
        <img id="w2" src="images/w4.jpg" alt="Cinque Terre" width="500" height="400">
    </a>
    <div class="desc">Exclusive Designer Red Lehenga Set-Bridal Lehenga Store CM334 </div>
</div>

<div class="gallery ">
    <a target="_blank" href="details.php?id=1">
        <img id="w3" src="images/w5.jpg" alt="Cinque Terre" width="500" height="400">
    </a>
    <div class="desc">Exclusive Designer Red Lehenga Set-Bridal Lehenga Store CM334 </div>
</div>

</body>
</html>

