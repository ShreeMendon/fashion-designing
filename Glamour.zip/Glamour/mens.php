<?php
?>
<!DOCTYPE html>
<html>
<head>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <style>
        div.gallery {
            margin: 5px;
            border: 1px solid #ccc;
            float: left;
            width: 355px;
            padding:20px;
            margin-left:5%;
            margin-top:6%;
        }

        div.gallery:hover {
            border: 1px solid #777;
        }

        div.gallery img {
            width: 100%;
            height: auto;

        }

        div.desc {
            padding: 20px;
            text-align: center;
            color:gray;

        }
        body{
            background-color:black;
        }
    </style>
</head>
<body>
<div class="gallery ">
    <a target="_blank" href="details_men.php">
        <img id="m1" src="images/m1.jpg" alt="" width="500" height="400">
    </a>
    <div class="desc">Exclusive Red Color Designer Sherwani Set Store CM334</div>
</div>

<div class="gallery ">
    <a target="_blank" href="details_men.php">
        <img id="m2" src="images/m2.jpg" alt="" width="500" height="400">
    </a>
    <div class="desc">Exclusive Black Color Designer Sherwani Set Store CM335 </div>
</div>

<div class="gallery ">
    <a target="_blank" href="details_men.php">
        <img id="m3" src="images/m3.jpg" alt="" width="500" height="400">
    </a>
    <div class="desc">Exclusive Maroon Color Designer Sherwani Set Store CM336 </div>
</div>

</body>
</html>

